import numpy as np 
from matplotlib import pyplot as plt

with open('Audio') as f:
	rectype = np.dtype(np.int32)
	bdata = np.fromfile(f, dtype=rectype)

dsize = bdata.size

t = np.linspace(0,100, bdata)

plt.plot(t, bdata)